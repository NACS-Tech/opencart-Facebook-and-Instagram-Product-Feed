<?php
namespace Opencart\Catalog\Controller\Extension\NacsFacebookFeed\Feed;

class NacsFacebookFeed extends \Opencart\System\Engine\Controller {

    public function index(): void {
        // Enabled check
        if (!$this->config->get('feed_nacs_facebook_feed_status')) {
            $this->response->redirect($this->url->link('error/not_found'));
            return;
        }

        // Token check
        $token = (string)$this->config->get('feed_nacs_facebook_feed_access_token');
        if (empty($this->request->get['token']) || (string)$this->request->get['token'] !== $token) {
            $this->response->redirect($this->url->link('error/not_found'));
            return;
        }

        // Override store/language/currency from URL (for multi-store feeds)
        $store_id = isset($this->request->get['store_id']) ? (int)$this->request->get['store_id'] : (int)$this->config->get('feed_nacs_facebook_feed_store_id');
        $language = isset($this->request->get['language']) ? (string)$this->request->get['language'] : (string)$this->config->get('feed_nacs_facebook_feed_language');
        $currency = isset($this->request->get['currency']) ? (string)$this->request->get['currency'] : (string)$this->config->get('feed_nacs_facebook_feed_currency');

        if (!empty($language)) {
            $this->config->set('config_language', $language);
            $this->session->data['language'] = $language;
        }
        if (!empty($currency)) {
            $this->session->data['currency'] = $currency;
        }

        $format = (string)($this->config->get('feed_nacs_facebook_feed_format') ?: 'xml');

        $cache_mode = (string)($this->config->get('feed_nacs_facebook_feed_cache_mode') ?: 'live'); // live|file
        $ttl = (int)($this->config->get('feed_nacs_facebook_feed_cache_ttl') ?: 3600);
        $is_cron = !empty($this->request->get['cron']);

        $cache_key = 'nacs_facebook_feed_' . $format . '_s' . $store_id . '_l' . preg_replace('/[^a-z0-9\-]/i', '', $language) . '_c' . preg_replace('/[^A-Z]/', '', $currency);
        $cache_file = DIR_STORAGE . 'download/' . $cache_key . '.' . $format;

        // If file cache enabled and cache valid, serve it (unless cron forces regenerate)
        if ($cache_mode === 'file' && !$is_cron) {
            if (is_file($cache_file) && (time() - filemtime($cache_file) < $ttl)) {
                $this->serveOutput((string)file_get_contents($cache_file), $format);
                return;
            }
        }

        // Generate fresh feed
        $output = $this->generateFeed($format, $currency);

        // Write cache file if enabled (cron can refresh)
        if ($cache_mode === 'file') {
            // Ensure directory exists
            if (!is_dir(DIR_STORAGE . 'download/')) {
                @mkdir(DIR_STORAGE . 'download/', 0755, true);
            }
            @file_put_contents($cache_file, $output);
        }

        $this->serveOutput($output, $format);
    }

    private function serveOutput(string $output, string $format): void {
        $gzip = (int)$this->config->get('feed_nacs_facebook_feed_gzip');

        // Content-Type
        if ($format === 'csv') {
            $this->response->addHeader('Content-Type: text/csv; charset=utf-8');
        } elseif ($format === 'tsv') {
            $this->response->addHeader('Content-Type: text/tab-separated-values; charset=utf-8');
        } else {
            $this->response->addHeader('Content-Type: application/xml; charset=utf-8');
        }

        // GZIP if client supports
        if ($gzip && isset($this->request->server['HTTP_ACCEPT_ENCODING']) && strpos($this->request->server['HTTP_ACCEPT_ENCODING'], 'gzip') !== false) {
            $this->response->addHeader('Content-Encoding: gzip');
            $output = gzencode($output, 9);
        }

        $this->response->setOutput($output);
    }

    private function generateFeed(string $format, string $currency): string {
        $this->load->model('catalog/product');
        $this->load->model('tool/image');

        $in_stock_only = (int)$this->config->get('feed_nacs_facebook_feed_instock_only');
        $min_qty       = (int)$this->config->get('feed_nacs_facebook_feed_min_qty');

        $category_id   = (int)$this->config->get('feed_nacs_facebook_feed_category_id');
        $include_sub   = (int)$this->config->get('feed_nacs_facebook_feed_include_subcat');

        $limit = (int)$this->config->get('feed_nacs_facebook_feed_limit');
        $start = (int)$this->config->get('feed_nacs_facebook_feed_start');

        $use_special = (int)$this->config->get('feed_nacs_facebook_feed_use_special');
        $use_tax     = (int)$this->config->get('feed_nacs_facebook_feed_use_tax');

        $img_w = (int)$this->config->get('feed_nacs_facebook_feed_image_w');
        $img_h = (int)$this->config->get('feed_nacs_facebook_feed_image_h');
        $add_images = (int)$this->config->get('feed_nacs_facebook_feed_additional_images');

        $filter = [
            'filter_status' => 1,
            'start' => $start,
            'limit' => $limit
        ];

        // Category filtering (best effort - depends on OC build)
        if ($category_id > 0) {
            $filter['filter_category_id'] = $category_id;
            $filter['filter_sub_category'] = $include_sub ? 1 : 0;
        }

        $products = $this->model_catalog_product->getProducts($filter);

        // Output init
        if ($format === 'csv') {
            $out = "id,title,description,link,image_link,additional_image_link,price,sale_price,availability,condition,brand,sku,mpn,gtin\n";
        } elseif ($format === 'tsv') {
            $out = "id\ttitle\tdescription\tlink\timage_link\tadditional_image_link\tprice\tsale_price\tavailability\tcondition\tbrand\tsku\tmpn\tgtin\n";
        } else {
            $out  = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
            $out .= "<rss version=\"2.0\" xmlns:g=\"http://base.google.com/ns/1.0\">\n";
            $out .= "<channel>\n";
            $out .= "<title>" . htmlspecialchars((string)$this->config->get('config_name')) . " - Product Feed</title>\n";
            $out .= "<link>" . $this->url->link('common/home') . "</link>\n";
            $out .= "<description>Product feed</description>\n";
        }

        foreach ($products as $p) {
            // Stock filter
            $qty = isset($p['quantity']) ? (int)$p['quantity'] : 0;
            if ($in_stock_only && $qty <= 0) continue;
            if ($min_qty > 0 && $qty < $min_qty) continue;

            $product_id = (int)$p['product_id'];
            $title = (string)($p['name'] ?? '');
            $desc  = (string)($p['description'] ?? '');
            $desc  = strip_tags(html_entity_decode($desc, ENT_QUOTES, 'UTF-8'));

            $link = $this->url->link('product/product', 'product_id=' . $product_id);

            // Brand: try manufacturer, else store name
            $brand = '';
            if (!empty($p['manufacturer'])) {
                $brand = (string)$p['manufacturer'];
            } elseif (!empty($p['brand'])) {
                $brand = (string)$p['brand'];
            } else {
                $brand = (string)$this->config->get('config_name');
            }

            // Images
            $image_link = '';
            if (!empty($p['image'])) {
                $image_link = $this->model_tool_image->resize($p['image'], $img_w, $img_h);
            }

            $additional_links = [];
            if ($add_images) {
                // Best-effort additional images
                if (method_exists($this->model_catalog_product, 'getProductImages')) {
                    $imgs = $this->model_catalog_product->getProductImages($product_id);
                    foreach ($imgs as $im) {
                        if (!empty($im['image'])) {
                            $additional_links[] = $this->model_tool_image->resize($im['image'], $img_w, $img_h);
                        }
                    }
                }
            }

            // Price / Special / Tax
            $price_value = (float)($p['price'] ?? 0.0);
            $special_value = 0.0;

            if ($use_special) {
                if (isset($p['special']) && $p['special'] !== null && $p['special'] !== false && $p['special'] !== '') {
                    $special_value = (float)$p['special'];
                }
            }

            // Tax calculation (best effort)
            $tax_class_id = (int)($p['tax_class_id'] ?? 0);
            if ($use_tax && $tax_class_id) {
                $price_value = (float)$this->tax->calculate($price_value, $tax_class_id, true);
                if ($special_value > 0) {
                    $special_value = (float)$this->tax->calculate($special_value, $tax_class_id, true);
                }
            }

            // Currency formatting: numeric without symbol
            $price_str = $this->currency->format($price_value, $currency, 1.0, false) . ' ' . $currency;
            $sale_str  = ($special_value > 0) ? ($this->currency->format($special_value, $currency, 1.0, false) . ' ' . $currency) : '';

            $availability = ($qty > 0) ? 'in stock' : 'out of stock';

            // IDs
            $sku = (string)($p['sku'] ?? '');
            $mpn = (string)($p['mpn'] ?? '');
            $gtin = '';
            // Pick best GTIN candidate
            foreach (['ean','upc','isbn','jan'] as $k) {
                if (!empty($p[$k])) { $gtin = (string)$p[$k]; break; }
            }

            $additional_joined = implode(',', $additional_links);

            if ($format === 'csv') {
                $row = [
                    $product_id,
                    '"' . str_replace('"', '""', $title) . '"',
                    '"' . str_replace('"', '""', $desc) . '"',
                    $link,
                    $image_link,
                    '"' . str_replace('"', '""', $additional_joined) . '"',
                    $price_str,
                    $sale_str,
                    $availability,
                    'new',
                    '"' . str_replace('"', '""', $brand) . '"',
                    '"' . str_replace('"', '""', $sku) . '"',
                    '"' . str_replace('"', '""', $mpn) . '"',
                    '"' . str_replace('"', '""', $gtin) . '"'
                ];
                $out .= implode(',', $row) . "\n";
            } elseif ($format === 'tsv') {
                $row = [
                    $product_id,
                    $title,
                    $desc,
                    $link,
                    $image_link,
                    $additional_joined,
                    $price_str,
                    $sale_str,
                    $availability,
                    'new',
                    $brand,
                    $sku,
                    $mpn,
                    $gtin
                ];
                // sanitize tabs/newlines
                $row = array_map(function($v){ return str_replace(["\t","\r","\n"], ' ', (string)$v); }, $row);
                $out .= implode("\t", $row) . "\n";
            } else {
                $out .= "<item>\n";
                $out .= "<g:id>{$product_id}</g:id>\n";
                $out .= "<g:title>" . htmlspecialchars($title) . "</g:title>\n";
                $out .= "<g:description>" . htmlspecialchars($desc) . "</g:description>\n";
                $out .= "<g:link>" . htmlspecialchars($link) . "</g:link>\n";
                if ($image_link) {
                    $out .= "<g:image_link>" . htmlspecialchars($image_link) . "</g:image_link>\n";
                }
                foreach ($additional_links as $al) {
                    $out .= "<g:additional_image_link>" . htmlspecialchars($al) . "</g:additional_image_link>\n";
                }
                $out .= "<g:price>" . htmlspecialchars($price_str) . "</g:price>\n";
                if ($sale_str) {
                    $out .= "<g:sale_price>" . htmlspecialchars($sale_str) . "</g:sale_price>\n";
                }
                $out .= "<g:availability>" . htmlspecialchars($availability) . "</g:availability>\n";
                $out .= "<g:condition>new</g:condition>\n";
                $out .= "<g:brand>" . htmlspecialchars($brand) . "</g:brand>\n";

                if ($sku)  $out .= "<g:sku>" . htmlspecialchars($sku) . "</g:sku>\n";
                if ($mpn)  $out .= "<g:mpn>" . htmlspecialchars($mpn) . "</g:mpn>\n";
                if ($gtin) $out .= "<g:gtin>" . htmlspecialchars($gtin) . "</g:gtin>\n";

                $out .= "</item>\n";
            }
        }

        if ($format === 'xml') {
            $out .= "</channel>\n</rss>";
        }

        return $out;
    }
}
