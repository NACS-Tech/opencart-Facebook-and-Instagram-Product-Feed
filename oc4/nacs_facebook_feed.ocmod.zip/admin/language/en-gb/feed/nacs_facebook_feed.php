<?php
$_['heading_title'] = 'NACS Facebook Catalog Feed (Advanced)';

$_['text_extension'] = 'Extensions';
$_['text_success']   = 'Success: You have modified NACS Facebook Feed!';
$_['text_edit']      = 'Edit NACS Facebook Catalog Feed';
$_['text_enabled']   = 'Enabled';
$_['text_disabled']  = 'Disabled';
$_['text_xml']       = 'XML (RSS 2.0 / Google)'; 
$_['text_csv']       = 'CSV';
$_['text_tsv']       = 'TSV';

$_['entry_status']   = 'Status';
$_['entry_format']   = 'Feed Format';
$_['entry_feed_url'] = 'Feed URL';
$_['entry_cron_url'] = 'Cron URL (Optional)';
$_['entry_token']    = 'Access Token';

$_['tab_general']    = 'General';
$_['tab_filters']    = 'Filters';
$_['tab_price']      = 'Price';
$_['tab_images']     = 'Images';
$_['tab_cache']      = 'Cache';

$_['entry_store']    = 'Store';
$_['entry_language'] = 'Language';
$_['entry_currency'] = 'Currency';

$_['entry_instock_only'] = 'In-stock only';
$_['entry_min_qty']      = 'Minimum Quantity';

$_['entry_category_id']  = 'Category ID (0 = All)';
$_['entry_subcat']       = 'Include Subcategories';

$_['entry_limit']        = 'Limit';
$_['entry_start']        = 'Start/Offset';

$_['entry_use_special']  = 'Use Special Price';
$_['entry_use_tax']      = 'Include Tax (if configured)';

$_['entry_img_w']        = 'Image Width';
$_['entry_img_h']        = 'Image Height';
$_['entry_additional_images'] = 'Include Additional Images';

$_['entry_gzip']         = 'GZIP Output (if supported)';

$_['entry_cache_mode']   = 'Cache Mode';
$_['entry_cache_ttl']    = 'Cache TTL (seconds)';

$_['help_feed_url']  = 'Copy this URL and add to Facebook Business Manager / Commerce Manager.';
$_['help_cron_url']  = 'Use this URL in server cron (curl/wget) to refresh cached feed (when cache mode = file).';
$_['help_token']     = 'Token required to access the feed URL.';
$_['help_category_id']= 'If you want only one category feed, set category_id. 0 = all categories.';
$_['help_limit']     = 'Large catalogs: use limit/start for pagination.';
$_['help_cache_mode']= 'live = generate every request; file = cache to storage file and serve until TTL expires.';

$_['button_save']    = 'Save';
$_['button_cancel']  = 'Cancel';
$_['button_regen_token'] = 'Regenerate Token';

$_['error_permission'] = 'Warning: You do not have permission to modify NACS Facebook Feed!';
