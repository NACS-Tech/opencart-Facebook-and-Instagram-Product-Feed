<?php
namespace Opencart\Admin\Controller\Extension\NacsFacebookFeed\Feed;

class NacsFacebookFeed extends \Opencart\System\Engine\Controller {
    private array $error = [];

    public function index(): void {
        $this->load->language('extension/nacs_facebook_feed/feed/nacs_facebook_feed');
        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            // regenerate token if requested
            if (!empty($this->request->post['feed_nacs_facebook_feed_regen_token'])) {
                $this->request->post['feed_nacs_facebook_feed_access_token'] = bin2hex(random_bytes(16));
            }

            $this->model_setting_setting->editSetting('feed_nacs_facebook_feed', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link(
                'marketplace/extension',
                'user_token=' . $this->session->data['user_token'] . '&type=feed',
                true
            ));
        }

        $data['error_warning'] = $this->error['warning'] ?? '';
        $data['success'] = $this->session->data['success'] ?? '';
        unset($this->session->data['success']);

        $data['breadcrumbs'] = [];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=feed')
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/nacs_facebook_feed/feed/nacs_facebook_feed', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['action'] = $this->url->link('extension/nacs_facebook_feed/feed/nacs_facebook_feed', 'user_token=' . $this->session->data['user_token']);
        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=feed');

        // Load stores for multi-store
        $this->load->model('setting/store');
        $stores = [];
        $stores[] = ['store_id' => 0, 'name' => $this->config->get('config_name') . ' (Default)'];
        foreach ($this->model_setting_store->getStores() as $s) {
            $stores[] = ['store_id' => (int)$s['store_id'], 'name' => $s['name']];
        }
        $data['stores'] = $stores;

        // Languages
        $this->load->model('localisation/language');
        $data['languages'] = $this->model_localisation_language->getLanguages();

        // Currencies
        $this->load->model('localisation/currency');
        $data['currencies'] = $this->model_localisation_currency->getCurrencies();

        // Helper to get posted or config
        $get = function(string $key, $default = '') {
            if (isset($this->request->post[$key])) return $this->request->post[$key];
            $v = $this->config->get($key);
            return ($v === null || $v === '') ? $default : $v;
        };

        // Settings (OC3-level)
        $data['feed_nacs_facebook_feed_status']          = $get('feed_nacs_facebook_feed_status', 0);
        $data['feed_nacs_facebook_feed_format']          = $get('feed_nacs_facebook_feed_format', 'xml');
        $data['feed_nacs_facebook_feed_access_token']    = $get('feed_nacs_facebook_feed_access_token', bin2hex(random_bytes(16)));

        $data['feed_nacs_facebook_feed_store_id']        = $get('feed_nacs_facebook_feed_store_id', 0);
        $data['feed_nacs_facebook_feed_language']        = $get('feed_nacs_facebook_feed_language', $this->config->get('config_language'));
        $data['feed_nacs_facebook_feed_currency']        = $get('feed_nacs_facebook_feed_currency', $this->config->get('config_currency'));

        $data['feed_nacs_facebook_feed_instock_only']    = (int)$get('feed_nacs_facebook_feed_instock_only', 0);
        $data['feed_nacs_facebook_feed_min_qty']         = (int)$get('feed_nacs_facebook_feed_min_qty', 0);

        $data['feed_nacs_facebook_feed_category_id']     = (int)$get('feed_nacs_facebook_feed_category_id', 0);
        $data['feed_nacs_facebook_feed_include_subcat']  = (int)$get('feed_nacs_facebook_feed_include_subcat', 1);

        $data['feed_nacs_facebook_feed_limit']           = (int)$get('feed_nacs_facebook_feed_limit', 5000);
        $data['feed_nacs_facebook_feed_start']           = (int)$get('feed_nacs_facebook_feed_start', 0);

        $data['feed_nacs_facebook_feed_use_special']     = (int)$get('feed_nacs_facebook_feed_use_special', 1);
        $data['feed_nacs_facebook_feed_use_tax']         = (int)$get('feed_nacs_facebook_feed_use_tax', 0);

        $data['feed_nacs_facebook_feed_image_w']         = (int)$get('feed_nacs_facebook_feed_image_w', 1000);
        $data['feed_nacs_facebook_feed_image_h']         = (int)$get('feed_nacs_facebook_feed_image_h', 1000);
        $data['feed_nacs_facebook_feed_additional_images']= (int)$get('feed_nacs_facebook_feed_additional_images', 1);

        $data['feed_nacs_facebook_feed_gzip']            = (int)$get('feed_nacs_facebook_feed_gzip', 0);

        // Caching / Cron
        $data['feed_nacs_facebook_feed_cache_mode']      = $get('feed_nacs_facebook_feed_cache_mode', 'live'); // live|file
        $data['feed_nacs_facebook_feed_cache_ttl']       = (int)$get('feed_nacs_facebook_feed_cache_ttl', 3600);

        $data['formats'] = [
            'xml' => $this->language->get('text_xml'),
            'csv' => $this->language->get('text_csv'),
            'tsv' => $this->language->get('text_tsv')
        ];

        // Feed & Cron URLs (store/lang/currency support)
        $base = HTTP_CATALOG . 'index.php?route=extension/nacs_facebook_feed/feed/nacs_facebook_feed';
        $params = '&token=' . $data['feed_nacs_facebook_feed_access_token']
            . '&store_id=' . (int)$data['feed_nacs_facebook_feed_store_id']
            . '&language=' . urlencode((string)$data['feed_nacs_facebook_feed_language'])
            . '&currency=' . urlencode((string)$data['feed_nacs_facebook_feed_currency']);

        $data['feed_url'] = $base . $params;
        $data['cron_url'] = $base . $params . '&cron=1';

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/nacs_facebook_feed/feed/nacs_facebook_feed', $data));
    }

    protected function validate(): bool {
        if (!$this->user->hasPermission('modify', 'extension/nacs_facebook_feed/feed/nacs_facebook_feed')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }

    public function install(): void {
        $this->load->model('setting/setting');

        $defaults = [
            'feed_nacs_facebook_feed_status' => 0,
            'feed_nacs_facebook_feed_format' => 'xml',
            'feed_nacs_facebook_feed_access_token' => bin2hex(random_bytes(16)),
            'feed_nacs_facebook_feed_store_id' => 0,
            'feed_nacs_facebook_feed_language' => $this->config->get('config_language'),
            'feed_nacs_facebook_feed_currency' => $this->config->get('config_currency'),
            'feed_nacs_facebook_feed_instock_only' => 0,
            'feed_nacs_facebook_feed_min_qty' => 0,
            'feed_nacs_facebook_feed_category_id' => 0,
            'feed_nacs_facebook_feed_include_subcat' => 1,
            'feed_nacs_facebook_feed_limit' => 5000,
            'feed_nacs_facebook_feed_start' => 0,
            'feed_nacs_facebook_feed_use_special' => 1,
            'feed_nacs_facebook_feed_use_tax' => 0,
            'feed_nacs_facebook_feed_image_w' => 1000,
            'feed_nacs_facebook_feed_image_h' => 1000,
            'feed_nacs_facebook_feed_additional_images' => 1,
            'feed_nacs_facebook_feed_gzip' => 0,
            'feed_nacs_facebook_feed_cache_mode' => 'live',
            'feed_nacs_facebook_feed_cache_ttl' => 3600
        ];

        $this->model_setting_setting->editSetting('feed_nacs_facebook_feed', $defaults);
    }

    public function uninstall(): void {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('feed_nacs_facebook_feed');
    }
}
