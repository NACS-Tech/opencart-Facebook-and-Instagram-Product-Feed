<?php
class ControllerExtensionFeedNacsFacebookFeed extends Controller {
    private $error = [];

    public function index() {
        $this->load->language('extension/feed/nacs_facebook_feed');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $post = $this->request->post;

            if (!empty($post['feed_nacs_facebook_feed_token_generate'])) {
                $post['feed_nacs_facebook_feed_token'] = bin2hex(random_bytes(16));
            }

            // Ensure token exists when enabled
            if (!empty($post['feed_nacs_facebook_feed_token_security']) && empty($post['feed_nacs_facebook_feed_token'])) {
                $post['feed_nacs_facebook_feed_token'] = bin2hex(random_bytes(16));
            }

            // Force prefix to start with nacs
            if (!empty($post['feed_nacs_facebook_feed_file_prefix'])) {
                $p = preg_replace('/[^a-z0-9_\-]/i', '', $post['feed_nacs_facebook_feed_file_prefix']);
                if (stripos($p, 'nacs') !== 0) {
                    $p = 'nacs_' . $p;
                }
                $post['feed_nacs_facebook_feed_file_prefix'] = $p;
            } else {
                $post['feed_nacs_facebook_feed_file_prefix'] = 'nacs_';
            }

            unset($post['feed_nacs_facebook_feed_token_generate']);

            $this->model_setting_setting->editSetting('feed_nacs_facebook_feed', $post);
            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=feed', true));
        }

        $data['breadcrumbs'] = [];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=feed', true)
        ];
        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/feed/nacs_facebook_feed', 'user_token=' . $this->session->data['user_token'], true)
        ];

        $data['action'] = $this->url->link('extension/feed/nacs_facebook_feed', 'user_token=' . $this->session->data['user_token'], true);
        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=feed', true);

        $defaults = [
            'feed_nacs_facebook_feed_status' => 1,
            'feed_nacs_facebook_feed_format' => 'xml',
            'feed_nacs_facebook_feed_include_out_of_stock' => 0,
            'feed_nacs_facebook_feed_price_tax' => 'incl',
            'feed_nacs_facebook_feed_gtin_field' => 'upc',
            'feed_nacs_facebook_feed_variants' => 'none',
            'feed_nacs_facebook_feed_token_security' => 1,
            'feed_nacs_facebook_feed_token' => '',
            'feed_nacs_facebook_feed_output_mode' => 'live', // live|cache
            'feed_nacs_facebook_feed_cache_ttl' => 60,
            'feed_nacs_facebook_feed_file_prefix' => 'nacs_',
            'feed_nacs_facebook_feed_include_quantity' => 0,
            'feed_nacs_facebook_feed_debug' => 0
        ];

        foreach ($defaults as $k => $v) {
            if (isset($this->request->post[$k])) {
                $data[$k] = $this->request->post[$k];
            } else {
                $val = $this->config->get($k);
                $data[$k] = ($val === null || $val === '') ? $v : $val;
            }
        }

        if (empty($data['feed_nacs_facebook_feed_token'])) {
            $data['feed_nacs_facebook_feed_token'] = bin2hex(random_bytes(16));
        }

        // Feed URL
        $base_url = defined('HTTPS_CATALOG') ? HTTPS_CATALOG : HTTP_CATALOG;
        $route = 'index.php?route=extension/feed/nacs_facebook_feed';
        if (!empty($data['feed_nacs_facebook_feed_token_security'])) {
            $route .= '&token=' . $data['feed_nacs_facebook_feed_token'];
        }
        $data['feed_url'] = $base_url . $route;

        // Dynamic credit link (UTM)
        $store_host = parse_url($base_url, PHP_URL_HOST);
        $utm = http_build_query([
            'utm_source' => $store_host ?: 'unknown_store',
            'utm_medium' => 'opencart_plugin',
            'utm_campaign' => 'nacs_facebook_feed',
            'utm_content' => 'admin_settings'
        ]);
        $data['nacs_credit_url'] = 'https://www.nacstech.in/?' . $utm;

        $data['error_warning'] = $this->error['warning'] ?? '';
        $data['user_token'] = $this->session->data['user_token'];

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/feed/nacs_facebook_feed', $data));
    }

    public function install() {
        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting('feed_nacs_facebook_feed', [
            'feed_nacs_facebook_feed_status' => 1,
            'feed_nacs_facebook_feed_format' => 'xml',
            'feed_nacs_facebook_feed_include_out_of_stock' => 0,
            'feed_nacs_facebook_feed_price_tax' => 'incl',
            'feed_nacs_facebook_feed_gtin_field' => 'upc',
            'feed_nacs_facebook_feed_variants' => 'none',
            'feed_nacs_facebook_feed_token_security' => 1,
            'feed_nacs_facebook_feed_token' => bin2hex(random_bytes(16)),
            'feed_nacs_facebook_feed_output_mode' => 'cache',
            'feed_nacs_facebook_feed_cache_ttl' => 60,
            'feed_nacs_facebook_feed_file_prefix' => 'nacs_',
            'feed_nacs_facebook_feed_include_quantity' => 0,
            'feed_nacs_facebook_feed_debug' => 0
        ]);
    }

    public function uninstall() {
        $this->load->model('setting/setting');
        $this->model_setting_setting->deleteSetting('feed_nacs_facebook_feed');
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/feed/nacs_facebook_feed')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }
}
