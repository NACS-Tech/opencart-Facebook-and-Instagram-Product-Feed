<?php
$_['heading_title']    = 'NACS Facebook Catalog Feed';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified NACS Facebook Catalog Feed!';
$_['text_edit']        = 'Edit NACS Facebook Catalog Feed';
$_['text_enabled']     = 'Enabled';
$_['text_disabled']    = 'Disabled';
$_['text_yes']         = 'Yes';
$_['text_no']          = 'No';
$_['text_xml']         = 'XML (RSS 2.0 with g: tags)';
$_['text_csv']         = 'CSV';
$_['text_tax_incl']    = 'Tax Included';
$_['text_tax_excl']    = 'Tax Excluded';
$_['text_variants_none']       = 'No variants (products only)';
$_['text_variants_single_opt'] = 'Variants by first selectable option';
$_['text_output_live']  = 'Live output (build on request)';
$_['text_output_cache'] = 'Cached output (file cache)';
$_['text_token_auto']   = 'Regenerate Token';
$_['text_feed_url']     = 'Feed URL';
$_['text_credit']       = 'Powered by NACS Tech';

// Entry
$_['entry_status']               = 'Status';
$_['entry_format']               = 'Default Feed Format';
$_['entry_include_out_of_stock'] = 'Include Out of Stock Products';
$_['entry_price_tax']            = 'Price';
$_['entry_gtin_field']           = 'GTIN Mapping Field';
$_['entry_variants']             = 'Variants';
$_['entry_token_security']       = 'Token Security';
$_['entry_token']                = 'Access Token';
$_['entry_output_mode']          = 'Output Mode';
$_['entry_cache_ttl']            = 'Cache TTL (minutes)';
$_['entry_file_prefix']          = 'Feed Filename Prefix';
$_['entry_include_quantity']     = 'Include Quantity column (CSV)';
$_['entry_debug']                = 'Debug (log warnings)';

// Help
$_['help_format']               = 'Default output format. You can override in URL using &format=xml or &format=csv.';
$_['help_include_out_of_stock'] = 'If disabled, only in-stock products will be exported.';
$_['help_price_tax']            = 'Choose whether to export price with tax included or excluded.';
$_['help_gtin_field']           = 'Map GTIN to one of your product identifier fields.';
$_['help_variants']             = 'Exports variants only for the FIRST selectable option (select/radio/image).';
$_['help_token_security']       = 'If enabled, feed URL will require a token parameter (?token=...).';
$_['help_token']                = 'Keep this token secret. You can regenerate it anytime.';
$_['help_output_mode']          = 'Cached mode stores the feed file and serves it until TTL expires (faster for large catalogs).';
$_['help_cache_ttl']            = 'How long the cached feed file is valid.';
$_['help_file_prefix']          = 'Prefix used in generated cached filenames (must start with nacs).';
$_['help_include_quantity']     = 'Adds quantity column in CSV output (optional).';
$_['help_debug']                = 'Writes warnings to system/storage/logs/error.log.';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify NACS Facebook Catalog Feed!';
