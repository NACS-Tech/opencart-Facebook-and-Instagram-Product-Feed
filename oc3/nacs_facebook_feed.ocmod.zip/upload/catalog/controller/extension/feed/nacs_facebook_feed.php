<?php
class ControllerExtensionFeedNacsFacebookFeed extends Controller {

    public function index() {
        if (!$this->config->get('feed_nacs_facebook_feed_status')) {
            $this->response->addHeader('HTTP/1.1 404 Not Found');
            return;
        }

        // Token security
        if ($this->config->get('feed_nacs_facebook_feed_token_security')) {
            $token = $this->config->get('feed_nacs_facebook_feed_token');
            $reqToken = $this->request->get['token'] ?? '';
            if (!$token || !hash_equals((string)$token, (string)$reqToken)) {
                $this->response->addHeader('HTTP/1.1 403 Forbidden');
                $this->response->setOutput('Forbidden');
                return;
            }
        }

        // Format override
        $format = $this->request->get['format'] ?? $this->config->get('feed_nacs_facebook_feed_format') ?? 'xml';
        $format = strtolower($format);
        if (!in_array($format, ['xml','csv'])) $format = 'xml';

        $output_mode = $this->config->get('feed_nacs_facebook_feed_output_mode') ?? 'live';
        if ($output_mode === 'cache') {
            $this->serveCached($format);
        } else {
            $this->serveLive($format);
        }
    }

    private function serveLive($format) {
        $this->load->model('extension/feed/nacs_facebook_feed');
        $result = $this->model_extension_feed_nacs_facebook_feed->buildFeed($format);

        $this->response->addHeader($result['content_type']);
        if (!empty($result['download_name'])) {
            $this->response->addHeader('Content-Disposition: attachment; filename="' . $result['download_name'] . '"');
        }
        $this->response->setOutput($result['body']);
    }

    private function serveCached($format) {
        $this->load->model('extension/feed/nacs_facebook_feed');

        $ttl_min = (int)($this->config->get('feed_nacs_facebook_feed_cache_ttl') ?? 60);
        if ($ttl_min < 1) $ttl_min = 60;

        $prefix = $this->config->get('feed_nacs_facebook_feed_file_prefix') ?? 'nacs_';
        if (stripos($prefix, 'nacs') !== 0) $prefix = 'nacs_' . $prefix;

        $store_id = (int)$this->config->get('config_store_id');
        $ext = ($format === 'csv') ? 'csv' : 'xml';

        $dir = rtrim(DIR_STORAGE, '/\\') . '/download/';
        if (!is_dir($dir)) @mkdir($dir, 0755, true);

        $file = $dir . $prefix . 'facebook_feed_store' . $store_id . '.' . $ext;

        $is_valid = false;
        if (file_exists($file)) {
            $age = time() - filemtime($file);
            if ($age <= ($ttl_min * 60)) {
                $is_valid = true;
            }
        }

        if (!$is_valid) {
            $result = $this->model_extension_feed_nacs_facebook_feed->buildFeed($format);
            file_put_contents($file, $result['body']);
        }

        // Serve file
        $body = file_get_contents($file);
        $content_type = ($format === 'csv') ? 'Content-Type: text/csv; charset=utf-8' : 'Content-Type: application/xml; charset=utf-8';

        $this->response->addHeader($content_type);
        $this->response->setOutput($body);
    }
}
