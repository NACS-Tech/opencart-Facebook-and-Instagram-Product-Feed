<?php
class ModelExtensionFeedNacsFacebookFeed extends Model {

    public function buildFeed($format = 'xml') {
        $data = $this->buildFeedData();

        if ($format === 'csv') {
            return $this->renderCsv($data['items']);
        }
        return $this->renderXml($data['items']);
    }

    public function buildFeedData() {
        $this->load->model('catalog/product');
        $this->load->model('tool/image');

        $include_oos = (int)$this->config->get('feed_nacs_facebook_feed_include_out_of_stock');
        $price_tax   = $this->config->get('feed_nacs_facebook_feed_price_tax') ?: 'incl';
        $gtin_field  = $this->config->get('feed_nacs_facebook_feed_gtin_field') ?: 'upc';
        $variants    = $this->config->get('feed_nacs_facebook_feed_variants') ?: 'none';
        $debug       = (int)$this->config->get('feed_nacs_facebook_feed_debug');

        $currency    = $this->config->get('config_currency');

        $filter_data = [
            'filter_status' => 1,
            'start' => 0,
            'limit' => 100000
        ];

        $products = $this->model_catalog_product->getProducts($filter_data);
        $items = [];

        foreach ($products as $product) {
            $in_stock = ((int)$product['quantity'] > 0);
            if (!$include_oos && !$in_stock) continue;

            if ($variants === 'single_option') {
                $variant_items = $this->buildSingleOptionVariants($product, $currency, $price_tax, $gtin_field);
                if (!empty($variant_items)) {
                    foreach ($variant_items as $vi) {
                        if (!$include_oos && $vi['availability'] !== 'in stock') continue;
                        $items[] = $vi;
                    }
                    continue;
                }
            }

            $items[] = $this->buildBaseItem($product, $currency, $price_tax, $gtin_field, $in_stock);
        }

        return ['items' => $items];
    }

    private function renderXml($items) {
        $shop_name = $this->config->get('config_name');
        $shop_desc = $this->config->get('config_meta_description');
        $shop_link = HTTPS_SERVER ?: HTTP_SERVER;

        $xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">' . "\n";
        $xml .= "  <channel>\n";
        $xml .= '    <title>' . $this->x($shop_name) . '</title>' . "\n";
        $xml .= '    <link>' . $this->x($shop_link) . '</link>' . "\n";
        $xml .= '    <description>' . $this->x($shop_desc) . '</description>' . "\n";

        foreach ($items as $item) {
            $xml .= "    <item>\n";
            $xml .= '      <g:id>' . $this->x($item['id']) . '</g:id>' . "\n";
            $xml .= '      <title>' . $this->x($item['title']) . '</title>' . "\n";
            $xml .= '      <description>' . $this->x($item['description']) . '</description>' . "\n";
            $xml .= '      <link>' . $this->x($item['link']) . '</link>' . "\n";
            if (!empty($item['image_link'])) $xml .= '      <g:image_link>' . $this->x($item['image_link']) . '</g:image_link>' . "\n";
            $xml .= '      <g:availability>' . $this->x($item['availability']) . '</g:availability>' . "\n";
            $xml .= '      <g:condition>new</g:condition>' . "\n";
            $xml .= '      <g:price>' . $this->x($item['price']) . '</g:price>' . "\n";
            if (!empty($item['sale_price'])) $xml .= '      <g:sale_price>' . $this->x($item['sale_price']) . '</g:sale_price>' . "\n";
            if (!empty($item['brand'])) $xml .= '      <g:brand>' . $this->x($item['brand']) . '</g:brand>' . "\n";
            if (!empty($item['gtin'])) $xml .= '      <g:gtin>' . $this->x($item['gtin']) . '</g:gtin>' . "\n";
            if (!empty($item['mpn']))  $xml .= '      <g:mpn>' . $this->x($item['mpn']) . '</g:mpn>' . "\n";
            if (!empty($item['item_group_id'])) $xml .= '      <g:item_group_id>' . $this->x($item['item_group_id']) . '</g:item_group_id>' . "\n";
            if (!empty($item['color'])) $xml .= '      <g:color>' . $this->x($item['color']) . '</g:color>' . "\n";
            if (!empty($item['size']))  $xml .= '      <g:size>' . $this->x($item['size']) . '</g:size>' . "\n";
            $xml .= "    </item>\n";
        }

        $xml .= "  </channel>\n";
        $xml .= "</rss>\n";

        return ['content_type' => 'Content-Type: application/xml; charset=utf-8', 'download_name' => null, 'body' => $xml];
    }

    private function renderCsv($items) {
        $include_qty = (int)$this->config->get('feed_nacs_facebook_feed_include_quantity');
        $headers = ['id','title','description','link','image_link','availability','condition','price','sale_price','brand','gtin','mpn','item_group_id','color','size'];
        if ($include_qty) $headers[] = 'quantity';

        $fh = fopen('php://temp', 'w+');
        fputcsv($fh, $headers);

        foreach ($items as $item) {
            $row = [];
            foreach ($headers as $h) $row[] = $item[$h] ?? '';
            fputcsv($fh, $row);
        }

        rewind($fh);
        $csv = stream_get_contents($fh);
        fclose($fh);

        return ['content_type' => 'Content-Type: text/csv; charset=utf-8', 'download_name' => 'nacs_facebook_feed.csv', 'body' => $csv];
    }

    private function buildBaseItem($product, $currency, $price_tax, $gtin_field, $in_stock) {
        $link = $this->url->link('product/product', 'product_id=' . (int)$product['product_id'], true);

        $image_link = '';
        if (!empty($product['image'])) {
            $image_link = $this->model_tool_image->resize($product['image'], 800, 800);
        }

        $price = $this->priceFmt($product['price'], $product['tax_class_id'], $currency, $price_tax);
        $sale_price = '';
        if (!empty($product['special']) && (float)$product['special'] > 0) {
            $sale_price = $this->priceFmt($product['special'], $product['tax_class_id'], $currency, $price_tax);
        }

        $brand = $product['manufacturer'] ?? '';
        $gtin = $this->gtin($product, $gtin_field);

        $mpn = $product['mpn'] ?? '';
        if (!$mpn) $mpn = $product['model'] ?? '';

        $desc = $this->clean($product['description'] ?? '');
        if (!$desc) $desc = $this->clean($product['meta_description'] ?? '');

        return [
            'id' => (string)$product['product_id'],
            'title' => (string)$product['name'],
            'description' => $desc,
            'link' => $link,
            'image_link' => $image_link,
            'availability' => $in_stock ? 'in stock' : 'out of stock',
            'condition' => 'new',
            'price' => $price,
            'sale_price' => $sale_price,
            'brand' => $brand,
            'gtin' => $gtin,
            'mpn' => $mpn,
            'item_group_id' => '',
            'color' => '',
            'size' => '',
            'quantity' => (int)($product['quantity'] ?? 0)
        ];
    }

    private function buildSingleOptionVariants($product, $currency, $price_tax, $gtin_field) {
        $this->load->model('catalog/product');
        $this->load->model('tool/image');

        $options = $this->model_catalog_product->getProductOptions((int)$product['product_id']);
        $selectable = [];
        foreach ($options as $opt) {
            if (in_array($opt['type'], ['select','radio','image'])) $selectable[] = $opt;
        }
        if (empty($selectable)) return [];

        $opt = $selectable[0];
        if (empty($opt['product_option_value'])) return [];

        $opt_name = strtolower($opt['name']);
        $is_color = (strpos($opt_name, 'color') !== false) || (strpos($opt_name, 'colour') !== false);
        $is_size  = (strpos($opt_name, 'size') !== false);

        $items = [];
        foreach ($opt['product_option_value'] as $ov) {
            $qty = isset($ov['quantity']) ? (int)$ov['quantity'] : (int)($product['quantity'] ?? 0);
            $in_stock = $qty > 0;

            $variant_id = $product['product_id'] . '-' . $ov['product_option_value_id'];
            $link = $this->url->link('product/product', 'product_id=' . (int)$product['product_id'], true);

            $image_link = '';
            if (!empty($product['image'])) {
                $image_link = $this->model_tool_image->resize($product['image'], 800, 800);
            }

            $base_price = (float)$product['price'];
            $base_special = (!empty($product['special']) && (float)$product['special'] > 0) ? (float)$product['special'] : 0.0;

            $adj = (float)$ov['price'];
            $prefix = $ov['price_prefix'] ?? '+';

            $final_price = $base_price;
            $final_special = $base_special;

            if ($adj > 0) {
                if ($prefix === '-') {
                    $final_price = max(0, $base_price - $adj);
                    if ($base_special > 0) $final_special = max(0, $base_special - $adj);
                } else {
                    $final_price = $base_price + $adj;
                    if ($base_special > 0) $final_special = $base_special + $adj;
                }
            }

            $price = $this->priceFmt($final_price, $product['tax_class_id'], $currency, $price_tax);
            $sale_price = '';
            if ($final_special > 0) $sale_price = $this->priceFmt($final_special, $product['tax_class_id'], $currency, $price_tax);

            $brand = $product['manufacturer'] ?? '';
            $gtin = $this->gtin($product, $gtin_field);
            $mpn = $product['mpn'] ?? '';
            if (!$mpn) $mpn = $product['model'] ?? '';

            $desc = $this->clean($product['description'] ?? '');
            if (!$desc) $desc = $this->clean($product['meta_description'] ?? '');

            $title = (string)$product['name'] . ' - ' . $opt['name'] . ': ' . $ov['name'];

            $items[] = [
                'id' => (string)$variant_id,
                'title' => $title,
                'description' => $desc,
                'link' => $link,
                'image_link' => $image_link,
                'availability' => $in_stock ? 'in stock' : 'out of stock',
                'condition' => 'new',
                'price' => $price,
                'sale_price' => $sale_price,
                'brand' => $brand,
                'gtin' => $gtin,
                'mpn' => $mpn,
                'item_group_id' => (string)$product['product_id'],
                'color' => $is_color ? $ov['name'] : '',
                'size'  => $is_size ? $ov['name'] : '',
                'quantity' => $qty
            ];
        }
        return $items;
    }

    private function priceFmt($price, $tax_class_id, $currency, $price_tax) {
        $price = (float)$price;
        $calc_tax = ($price_tax === 'incl');
        $value = $this->tax->calculate($price, (int)$tax_class_id, $calc_tax);
        $raw = $this->currency->format($value, $currency, 1.0, false);
        return number_format((float)$raw, 2, '.', '') . ' ' . $currency;
    }

    private function gtin($product, $field) {
        $field = strtolower((string)$field);
        if (!in_array($field, ['upc','ean','isbn','mpn'])) $field = 'upc';
        return trim((string)($product[$field] ?? ''));
    }

    private function clean($html) {
        $text = html_entity_decode((string)$html, ENT_QUOTES, 'UTF-8');
        $text = strip_tags($text);
        $text = preg_replace('/\s+/', ' ', $text);
        return trim($text);
    }

    private function x($str) {
        return htmlspecialchars((string)$str, ENT_XML1 | ENT_COMPAT, 'UTF-8');
    }
}
